function getData(username)
{
	console.log(username.value)
	const url='https://api.github.com/users/'.concat(username.value)+'/repos?';



	document.getElementById("container").innerHTML='';

	fetch(url)
	.then(data => data.json())
	.then(res =>{
		
		console.log(res);
		res.forEach(temp=>{
		let card = document.createElement("div");

		let name = document.createTextNode('Name:' + temp.name + ',   ');
        card.appendChild(name);

        let lang = document.createTextNode('Major Language:' + temp.language + ',   ');
        card.appendChild(lang);

        let forks = document.createTextNode('Forks count:' + temp.forks + ',   ');
        card.appendChild(forks);

        let watchers = document.createTextNode('Watchers count:' + temp.watchers_count + ',   ');
        card.appendChild(watchers);

        container.appendChild(card);

    });
	})
	.catch(err => console.log("Error:", err));
}